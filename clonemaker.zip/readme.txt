Clonemaker
==========

"Clonemaker" is an wordpress plugin. Main target of this plugin is to insert in new page content from another page, simulate a copy - paste action.

How to install
---------------

###First Easy Way

Download `clonemaker.zip` on your PC and remember location where archive a saved.

After that go to your Wordpress admin page, from menu chose `plugins>add new`

Press on `Upload Plugin` button on top near **Add Plugins** heading

Now `Chose File` and show path to downloaded archieve after that press `Install Now` button

After successful upload  you can activate the plugin


###Second  Way

Unzip downloaded `clonemaker.zip` 

And copy unzipped files in `wp-content>plugins` folder of  your wordpress folder

After that login to your Wordpress admin page go to `plugins` in menu, and find plugin with "Clone Maker" title and press `Activate`


How to use
---------------
First of all you must activate it if is not active. Go to your Wordpress admin page , chose `plugins` form menu, in list find plugin with "Clone Maker" title and press `Activate`

Create some Wordpress page in `pages` section if you don't have yet else hit `Add New` button on `pages` section
now in right part you see the plugin with title `Clone from Page` where is displayed list of available page to get content from it.

![alt text](helpimage/1a.png "Title")


Press on `+++` link to get the content from selected page, editor is fit with loaded content from selected page.