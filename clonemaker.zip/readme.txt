=== Clonemaker ===
Plugin URI:https://github.com/nosstradamus/Clonemaker
Author: Sitnic Victor
Author URI: https://github.com/nosstradamus
Contributors: SitnicVictor
Donate link:
Tags: page, clone, dublicate, copy, paste, content
Stable tag: 1
Version: 1
Requires at least: 2.6
Tested up to: 4.0.1

This Plugin simulate a copy - paste action for the page

== Description ==
"Clonemaker" is an wordpress plugin. Main target of this plugin is to insert in new page content from another page, simulate a copy - paste action.
More features coming soon...

Plugin Updated Nov-29th

== Installation ==
###First Easy Way
Download `clonemaker.zip` on your PC and remember location where archive a saved.
After that go to your Wordpress admin page, from menu chose `plugins>add new`
Press on `Upload Plugin` button on top near **Add Plugins** heading
Now `Chose File` and show path to downloaded archieve after that press `Install Now` button
After successful upload  you can activate the plugin

###Second  Way
Unzip downloaded `clonemaker.zip` 
And copy unzipped files in `wp-content>plugins` folder of  your wordpress folder
After that login to your Wordpress admin page go to `plugins` in menu, and find plugin with "Clone Maker" title and press `Activate`

How to use
---------------
First of all you must activate it if is not active. Go to your Wordpress admin page , chose `plugins` form menu, in list find plugin with "Clone Maker" title and press `Activate`
Create some Wordpress page in `pages` section if you don't have yet else hit `Add New` button on `pages` section
now in right part you see the plugin with title `Clone from Page` where is displayed list of available page to get content from it.
Press on `+++` link to get the content from selected page, editor is fit with loaded content from selected page.

== Screenshots ==
1. Plgin View in sidebar

== Changelog ==

= 29.11.2014 =
* First versions uploaded to WordPress.

== Upgrade Notice ==
