<?php
defined('ABSPATH') or die("No script kiddies please!");
/**
 * Plugin Name: Clone Maker
 * Plugin URI:https://github.com/nosstradamus/Clonemaker
 * Description: "Clonemaker" is an wordpress plugin. Main target of this plugin is to insert in new page content from another page, simulate a copy - paste action.
 * Version: 1.0
 * Author:Sitnic Victor
 * Author URI: https://github.com/nosstradamus
 * Text Domain: #
 * Domain Path: #
 * Network: #
 * License: GPL2
 *Copyright 2014  SITNIC VICTOR  (email : sitnic.victor@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
*/
 include "functions.php";
